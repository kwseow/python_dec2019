time_in_sec = 1000
time_in_mins = 1000 // 60

print ("Minutes: " + str(time_in_mins))

remaining_secs = 1000 % 60

print ("Remaining Seconds: " + str(remaining_secs))

print ("Time in mins and secs: " + str(time_in_mins) + "min and " + str(remaining_secs) + "sec")