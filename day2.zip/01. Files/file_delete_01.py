import os

print(os.getcwd())

# delete directory (can only delete empty folder)
#os.rmdir("folder3")

import shutil
# delete directory (with content)
shutil.rmtree("folder3")


