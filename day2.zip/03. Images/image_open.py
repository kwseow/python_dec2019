import os
from PIL import Image

filename = "img/clungup.jpg"

im = Image.open(filename)

im.show()

