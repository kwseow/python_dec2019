import os
from PIL import Image, ImageFilter, ImageOps

filename = "img/clungup.jpg"

im = Image.open(filename)
out = im.transpose(Image.ROTATE_90)

im.show()
out.show()
